// mathModule.js - Heat Index Calculation Module
function calculateHeatIndex(temperature, humidity) {
  // Formula for Heat Index approximation
  const heatIndex = temperature + 0.5555 * (6.11 * Math.exp(5417.7530 * (1/273.16 - 1/(273.15 + temperature))) * (humidity / 100) - 10);
  return parseFloat(heatIndex.toFixed(2));
}

function getHeatwaveStatus(temperature) {
  if (temperature >= 40) {
    return "WARNING: Heatwave Condition";
  } else if (temperature >= 35) {
    return "ALERT: High Temperature";
  } else {
    return "NORMAL: Safe Temperature";
  }
}

module.exports = {
  calculateHeatIndex,
  getHeatwaveStatus
};