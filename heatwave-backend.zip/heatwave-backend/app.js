
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const math = require('./mathModule');
const HeatwaveData = require('./models/HeatwaveData');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Connect to Local MongoDB Database via Mongoose
mongoose.connect('mongodb://127.0.0.1:27017/heatwaveDB')
  .then(() => console.log('Successfully connected to local MongoDB (heatwaveDB)!'))
  .catch((err) => console.error('MongoDB connection error:', err));

// ==========================================
// RESTful CRUD ROUTES
// ==========================================

// 1. CREATE Operation (POST)
app.post('/api/heatwave', async (req, res) => {
  try {
    const { region, stationId, temperature, humidity } = req.body;
    const computedHeatIndex = math.calculateHeatIndex(temperature, humidity);
    const computedStatus = math.getHeatwaveStatus(temperature);

    const newReading = new HeatwaveData({
      region,
      stationId,
      temperature,
      humidity,
      heatIndex: computedHeatIndex,
      status: computedStatus
    });

    const savedReading = await newReading.save();
    res.status(201).json({ message: 'Heatwave record created successfully', data: savedReading });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 2. READ Operation (GET) - Retrieves all records using comparison filter ($gte)
app.get('/api/heatwave', async (req, res) => {
  try {
    const records = await HeatwaveData.find({ temperature: { $gte: 30 } });
    res.status(200).json(records);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 3. READ Single Record by ID (GET)
app.get('/api/heatwave/:id', async (req, res) => {
  try {
    const record = await HeatwaveData.findById(req.params.id);
    if (!record) return res.status(404).json({ message: 'Record not found' });
    res.status(200).json(record);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 4. UPDATE Operation (PUT)
app.put('/api/heatwave/:id', async (req, res) => {
  try {
    const { temperature, humidity } = req.body;
    let updateFields = { ...req.body };

    if (temperature && humidity) {
      updateFields.heatIndex = math.calculateHeatIndex(temperature, humidity);
      updateFields.status = math.getHeatwaveStatus(temperature);
    }

    const updatedRecord = await HeatwaveData.findByIdAndUpdate(req.params.id, updateFields, { new: true });
    res.status(200).json({ message: 'Record updated successfully', data: updatedRecord });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 5. DELETE Operation (DELETE)
app.delete('/api/heatwave/:id', async (req, res) => {
  try {
    await HeatwaveData.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Record deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Frontend View Dashboard Route
app.get('/dashboard', async (req, res) => {
  try {
    const records = await HeatwaveData.find();
    res.render('dashboard', { title: 'IMD Heatwave Early Warning Dashboard', records });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Express Server running on http://localhost:${PORT}`);
});